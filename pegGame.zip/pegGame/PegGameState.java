public enum PegGameState {
    NOT_STARTED,
    IN_PROGRESS,
    STALEMATE,
    WON;
}
