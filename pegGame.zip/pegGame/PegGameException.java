public class PegGameException extends Exception {
    public PegGameException(String message){
        super(message);
    }

    
}
